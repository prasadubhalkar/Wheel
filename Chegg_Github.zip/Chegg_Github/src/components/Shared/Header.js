import React from 'react';

class Header extends React.Component {
    render() {
        return (
            <div>
                <h1>Github issue management</h1>
            </div>
        );
    }
}

export default Header;
