import Modal from 'react-bootstrap/lib/Modal';
import React from 'react';
import PropTypes from 'prop-types';
import './modal.scss';

class ModalDialog extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showModal: false,
            modalSize: "sm"
        };
        this.footer = this.footer.bind(this);
        this.header = this.header.bind(this);
        this.body = this.body.bind(this);
        this.open = this.open.bind(this);
        this.close = this.close.bind(this);
    }

    header() {
        const hideDefaultClose = (this.props.attrs.showDefaultClose === "show");
        return (
            <Modal.Header closeButton={hideDefaultClose}>
                <Modal.Title>{this.props.attrs.title}</Modal.Title>
            </Modal.Header>
        );
    }

    body() {
        return (
            <Modal.Body>
                {this.props.children}
            </Modal.Body>
        );
    }

    footer() {
        const showCancelBtn = (this.props.attrs.showCancelBtn === "show");
        const showSubmitBtn = (this.props.attrs.showSubmitBtn === "show");
        return (
            <Modal.Footer>
                {showCancelBtn && <button type="button" className="btn btn-primary" onClick={this.props.attrs.onCancel}>
                    {this.props.attrs.cancelLabel}
                </button> }
                {showSubmitBtn && <button type="button" className="btn btn-primary" onClick={this.props.attrs.onSubmit}>
                    {this.props.attrs.submitLabel}
                </button> }
            </Modal.Footer>
        );
    }

    open() {
        this.setState({
            showModal: true
        });
    }

    close() {
        this.setState({
            showModal: false
        });
    }

    render() {
        const showPopup = this.state.showModal;
        const modalSize = (this.props.attrs.size === "large") ? "lg": "sm";
        const autoFocus = true;
        const closeOnEscape = false;
        return (
            <Modal show={showPopup}
                   onHide={this.close}
                   backdrop={"static"}
                   autoFocus={autoFocus}
                   bsSize={modalSize}
                   className={"modalWrapper"}
                   keyboard={closeOnEscape}>
                {this.header()}
                {this.body()}
                {this.footer()}
            </Modal>
        );
    }
}
ModalDialog.propTypes = {
    attrs: PropTypes.object.isRequired,
    children: PropTypes.object.isRequired
};

export default ModalDialog;