class GetGitUsers {
    static getData(accessToken) {
        return fetch(
            process.env.GIT_API_REPO_URL,
            {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    Authorization: "token " + accessToken
                }
            }
        );
    }

    static getRepoIssues(accessToken, repoName) {
        return fetch(
            process.env.GIT_API_ISSUES_URL + repoName + "/issues",
            {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    Authorization: "token " + accessToken
                }
            }
        );
    }
}

export default GetGitUsers;
