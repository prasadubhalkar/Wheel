export default {
    github: {
        userAccessToken: null,
        selectedRepo: null,
        userRepoList: null,
        issuesByRepositories: {}
    },
    http: {
        ajaxCallInProgress: false,
        errorMessage: null
    }
};