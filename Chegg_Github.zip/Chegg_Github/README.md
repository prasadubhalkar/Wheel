# Chegg Prasad Ubhalkar Assessment

  ## Install Node and Node Packages
    Needs Node to be installed on System Preferred (5.0 or above)
  
  ## Project Setup
    Navigate to the project directory from terminal
    Run the command "yarn" or "npm install" to install all the node packages needed for the project
    Run "npm start" and navigate to http://localhost:3000 to see the output
    
  ## Project Structure
    Source (src)
      actions
        |- Action Types (actionTypes)
        |- HTTP Request Actions (httpRequestActions.js)
      assests
        |- Images (img)
        |- Style Sheets (Global Styles)
      components
        |- [Component Name]
          |-- Component Specific Styles
        |- Shared Components
          |-- [Component Name]
        |- Parent Component (App.js)
        |- Routes Component (AppRoute.js)
      reducers
        |- [Reducer Name]
      services
        |- [API Service]
      store
        |- [Application Store]
      index.html
      index.js
    Config
      |- Webpack configuration
    Packages (package.json)
   
  ## Features
    React Redux
    Docker with ngInx
    Webpack with Dev
    Sass integration
    
    
  
      
      
