const webpack = require('webpack');
const webpackMerge = require('webpack-merge');
const commonConfig = require('./commonConfig');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const GLOBALS = {
    ENV: "development",
    GIT_API_REPO_URL: "https://api.github.com/user/repos",
    GIT_API_ISSUES_URL: "https://api.github.com/repos/",
    NODE_ENV: "development"
};
module.exports = function() {
    return webpackMerge(commonConfig(GLOBALS.ENV), {
        devtool: 'inline-source-map',
        entry: path.resolve(__dirname, '../src/index'),
        target: 'web',
        plugins: [
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, '../src/index.html'),
                title: "Complex Lending - Doc Up"
            }),
            new webpack.HotModuleReplacementPlugin(),
            new webpack.DefinePlugin({
                'process.env': {
                    'ENV': JSON.stringify(GLOBALS.ENV),
                    'GIT_API_REPO_URL': JSON.stringify(GLOBALS.GIT_API_REPO_URL),
                    'GIT_API_ISSUES_URL': JSON.stringify(GLOBALS.GIT_API_ISSUES_URL),
                    'NODE_ENV': JSON.stringify(GLOBALS.NODE_ENV)
                }
            })
        ],
        devServer: {
            contentBase: path.resolve(__dirname, '../src'),
            port: 3000,
            host: "localhost",
            historyApiFallback: true,
            watchOptions: {
                aggregateTimeout: 300,
                poll: 1000
            }
        }
    });
};