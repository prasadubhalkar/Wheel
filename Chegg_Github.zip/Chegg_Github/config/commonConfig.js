const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = function(env) {
    if(env === "production"){
        process.env.NODE_ENV = 'production';
    }
    return {
        entry: path.resolve(__dirname, '../src/index'),
        target: 'web',
        output: {
            path: path.resolve(__dirname, '../dist'), // Note: Physical files are only output by the production build task `npm run build`.
            publicPath: '/',
            filename: 'bundle.js'
        },
        plugins: [
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, '../src/index.html'),
                title: "Complex Lending - Doc Up"
            }),
            new CopyWebpackPlugin([
                {
                    from: path.resolve(__dirname, '../node_modules/bootstrap/dist/css/bootstrap.min.css'),
                    to: path.resolve(__dirname, '../dist/bootstrap.min.css')
                }
            ])
        ],
        module: {
            loaders: [
                {
                    test: /\.js$/,
                    include: path.join(__dirname, '../src'),
                    loaders: ['babel-loader']
                },
                {
                    test: /\.eot|jpg|png|gif(\?v=\d+\.\d+\.\d+)?$/,
                    loader: 'file-loader'
                },
                {
                    test: /\.(woff|woff2)$/,
                    loader: 'url-loader?prefix=font/&limit=5000'
                },
                {
                    test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
                    loader: 'url-loader?limit=10000&mimetype=application/octet-stream'
                },
                {
                    test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
                    loader: 'url-loader?limit=10000&mimetype=image/svg+xml'
                },
                {
                    test: /(\.css)$/,
                    loaders: ['style-loader', 'css-loader']
                },
                {
                    test: /(\.scss|\.sass)$/,
                    loaders: ['style-loader', 'css-loader', 'sass-loader']
                }
            ]
        }
    }
};
