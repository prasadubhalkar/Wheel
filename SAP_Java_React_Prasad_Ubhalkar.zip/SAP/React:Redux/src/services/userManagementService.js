class UserManagementService {
    static getUsers() {
        return fetch(
            process.env.BACKENDURL +
            '/users',
            {
                method: 'GET',
                headers: {'Content-Type': 'application/json'}
            }
        );
    }
    static createUser(userId, userBody) {
        return fetch(
            process.env.BACKENDURL +
            '/users/'+userId,
            {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(userBody)
            }
        );
    }
}

export default UserManagementService;
