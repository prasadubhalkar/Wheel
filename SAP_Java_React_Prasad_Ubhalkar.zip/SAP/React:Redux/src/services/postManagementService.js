class PostManagementService {
    static getPosts() {
        return fetch(
            process.env.BACKENDURL +
            '/posts',
            {
                method: 'GET',
                headers: {'Content-Type': 'application/json'}
            }
        );
    }

    static getPost(postId) {
        return fetch(
            process.env.BACKENDURL +
            '/post/'+ postId,
            {
                method: 'GET',
                headers: {'Content-Type': 'application/json'}
            }
        );
    }

    static deletePost(postId) {
        return fetch(
            process.env.BACKENDURL +
            '/post/'+ postId,
            {
                method: 'DELETE',
                headers: {'Content-Type': 'application/json'}
            }
        );
    }

    static updatePost(postId, postBody) {
        return fetch(
            process.env.BACKENDURL +
            '/posts/'+ postId,
            {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(postBody)
            }
        );
    }

    static createPost(postBody) {
        return fetch(
            process.env.BACKENDURL +
            '/posts',
            {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(postBody)
            }
        );
    }
}

export default PostManagementService;
