import PropTypes from 'prop-types';
import React from 'react';
import Modal from 'react-bootstrap/lib/Modal';
import Toaster from 'toastr';

class CreateNewUserPage extends React.Component {
    constructor(context, props) {
        super(context, props);
        this.updateUserName = this.updateUserName.bind(this);
        this.updateUserId = this.updateUserId.bind(this);
        this.createNewUser = this.createNewUser.bind(this);
    }

    componentWillMount() {
        this.setState({
            name: "",
            userId: ""
        });
    }

    updateUserName(event){
        this.setState({
            name: event.target.value
        });
    }

    updateUserId(event){
        this.setState({
            userId: event.target.value
        });
    }

    createNewUser() {
        if(!this.state.userId.trim()) {
            Toaster.error("Please enter a user id");
        }
        if(!this.state.name.trim()) {
            Toaster.error("Please enter a user name");
        }
        if(this.props.existingUserIds()[this.state.userId]) {
            Toaster.error("User already exists");
        }
        else {
            let userData = {
                name: this.state.name,
                userId: this.state.userId
            };
            this.props.createNewUserHandler(userData);
        }
    }

    render() {
        let self = this;
        return(
            <Modal
                show={this.props.showCreateNewUser}
                onHide={close}
                keyboard={false}
                aria-labelledby="contained-modal-title">
                <Modal.Header closeButton={false}>
                    <Modal.Title id="contained-modal-title">Register New User</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"form-group"}>
                        <label htmlFor={"userName"}>User Name</label>
                        <input className={"form-control"} id={"userName"} type={"text"} onChange={function(event) {
                            self.updateUserName(event);
                        }} placeholder={"Enter User Name"}/>
                    </div>
                    <div className={"form-group"}>
                        <label htmlFor={"userId"}>User Id</label>
                        <input className={"form-control"} id={"userId"} type={"text"}
                               onBlur={function(event) {
                                   self.updateUserId(event);
                               }}
                               onChange={function(event) {
                                   self.updateUserId(event);
                               }} placeholder={"Enter User Id"}/>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <input type={"button"} onClick={this.createNewUser} className={"btn btn-primary"} value={"Create"}/>
                    <input type={"button"} onClick={this.props.cancelCreateNewUser} className={"btn"} value={"Cancel"}/>
                </Modal.Footer>
            </Modal>
        );
    }
}

CreateNewUserPage.propTypes = {
    createNewUserHandler: PropTypes.func.isRequired,
    cancelCreateNewUser: PropTypes.func.isRequired,
    showCreateNewUser: PropTypes.bool.isRequired,
    existingUserIds: PropTypes.func.isRequired
};

export default CreateNewUserPage;