import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as usersManagementAction from '../../actions/userManagerActions';
import CreateNewUser from './CreateNewUser';

class UserPage extends React.Component {
    constructor(context, props) {
        super(context, props);
        this.updateUserName = this.updateUserName.bind(this);
        this.validateName = this.validateName.bind(this);
        this.toggleShowCreateNewUser = this.toggleShowCreateNewUser.bind(this);
        this.getUserIdArray = this.getUserIdArray.bind(this);
        this.handleCreateNewUser = this.handleCreateNewUser.bind(this);
    }

    componentWillMount(){
        this.props.actions.getUsers();
        this.setState({
            userId: "",
            invalidUserId: false,
            showCreateNewUser: false
        });
    }

    updateUserName(event) {
        this.setState({
            userId: event.target.value
        });
    }

    validateName(history) {
        let users = this.props.users;
        let userId = null;
        if(users && users.length && this.state.userId.trim()) {
            for(let i = 0; i < users.length; i++) {
                if(users[i].id === this.state.userId) {
                    userId = users[i].id;
                    break;
                }
            }
        }

        if(!userId) {
            this.setState({
                invalidUserId: true
            });
        }
        else {
            this.props.actions.setCurrentUser(userId);
            history.push('/posts/');
        }
    }

    getUserIdArray() {
        let users = this.props.users;
        let userIds = {};
        for(let i = 0; i < users.length; i++) {
            userIds[users[i].id] = true;
        }
        return userIds;
    }

    toggleShowCreateNewUser() {
        this.setState({
            showCreateNewUser: !this.state.showCreateNewUser
        });
    }

    handleCreateNewUser(userData) {
        this.props.actions.createUser(userData.userId, userData);
        this.toggleShowCreateNewUser();
    }

    render() {
        let self = this;
        let invalidUserId = this.state.invalidUserId;
        let showCreateNewUser = this.state.showCreateNewUser;
        const NavigateToPosts = withRouter(({history, index}) => (
            <input className={"btn btn-primary"} type={"button"} onClick={function() {
                self.validateName(history);
            }} value={"Login"}/>
        ));
        return(
            <div className={"userContainer"}>
                <div className="form-group">
                    <label htmlFor="userId">User ID : </label>
                    <input className={"form-control"} id={"userId"} type={"text"} onChange={
                        function(event) {
                            self.updateUserName(event);
                        }
                    } placeholder={"Please enter your user id"}/>
                </div>
                <div className="form-group">
                    <NavigateToPosts/>
                    <button className={"btn btn-primary"} onClick={this.toggleShowCreateNewUser}>{"Register"}</button>
                </div>
                <CreateNewUser
                    cancelCreateNewUser={this.toggleShowCreateNewUser}
                    showCreateNewUser={showCreateNewUser}
                    existingUserIds={this.getUserIdArray}
                    createNewUserHandler={this.handleCreateNewUser}
                />
                {invalidUserId && <div className={"danger"}>Invalid User Id entered, Please try again</div>}
            </div>
        );
    }
}

UserPage.propTypes = {
    users: PropTypes.array,
    actions: PropTypes.object.isRequired
};

function mapStateToProps(state, ownProps) {
    return {
        loading: state.ajaxCallInProgress > 0,
        users: state.userManager.users
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(usersManagementAction, dispatch)
    };
}
export default connect(mapStateToProps, mapDispatchToProps)(UserPage);
