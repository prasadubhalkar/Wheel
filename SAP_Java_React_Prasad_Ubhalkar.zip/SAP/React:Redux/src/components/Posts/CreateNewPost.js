import PropTypes from 'prop-types';
import React from 'react';
import Modal from 'react-bootstrap/lib/Modal';
import Toaster from 'toastr';

class CreateNewPostPage extends React.Component {
    constructor(context, props) {
        super(context, props);
        this.updatePostName = this.updatePostName.bind(this);
        this.createNewPost = this.createNewPost.bind(this);
        this.updatePostOptions = this.updatePostOptions.bind(this);
        this.updateActiveHours = this.updateActiveHours.bind(this);
    }

    componentWillMount() {
        this.setState({
            postName: "",
            postOptions: {},
            duration: 0
        });
    }

    updatePostName(event){
        this.setState({
           postName: event.target.value
        });
    }

    updateActiveHours(hours) {
        this.setState({
            duration: hours
        });
    }

    updatePostOptions(event, index) {
        let options = Object.assign([], this.state.postOptions);
        if(options && options[index]) {
            options[index] = event.target.value;
        }
        else {
            options[index] = event.target.value;
        }
        this.setState({
            postOptions: options
        });
    }

    createNewPost() {
        if(!this.state.postName.trim()) {
            Toaster.error("Post Name Cannot be empty");
        }
        else if(!this.postOptionsAreValid(this.state.postOptions)) {
            Toaster.error("Duplicate Options found");
        }
        else {
            let postData = {
                name: this.state.postName,
                options: this.state.postOptions,
                duration: this.state.duration
            };
            this.props.createNewHandler(postData);
        }
    }

    postOptionsAreValid(postOptions){
        let postsMap = {};
        for(let i = 0; i < postOptions.length; i++) {
            if(!postsMap[postOptions[i]]) {
                postsMap[postOptions[i]] = postOptions[i];
            }
            else {
                return false;
            }
        }
        return true;
    }

    render() {
        let self = this;
        let newOptions = new Array(3).fill(0);
        let postHours = new Array(10).fill(0);
        return(
            <Modal
                show={this.props.showCreateNewPost}
                onHide={close}
                keyboard={false}
                aria-labelledby="contained-modal-title">
                <Modal.Header closeButton={false}>
                    <Modal.Title id="contained-modal-title">Create New Post</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"form-group"}>
                        <label htmlFor={"postName"}>Post Name</label>
                        <input className={"form-control"} id={"postName"} type={"text"} onChange={function(event) {
                            self.updatePostName(event);
                        }} placeholder={"Enter Post Name"}/>
                    </div>
                    <div className={"form-group"}>
                        <label htmlFor={"postName"}>Post Options</label>
                        <div id={"postOptions"}>
                            {
                                newOptions.map((option, index) => {
                                    return <input key={index}
                                                  type={"text"}
                                                  className={"form-control"}
                                                  onChange={function(event) {
                                                      self.updatePostOptions(event, index);
                                                  }}
                                    />;
                                })
                            }
                        </div>
                    </div>
                    <div className={"form-group"}>
                        <label htmlFor={"expireHours"}>Expires (in Hours)</label>
                        <select className={"form-control"} id={"expireHours"} onChange={function(event){
                            self.updateActiveHours(parseInt(event.target.value));
                        }}>
                            {
                                postHours.map((hour, index)=> {
                                    return <option key={index}> {index + 1} </option>;
                                })};
                            }
                        </select>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <input type={"button"} onClick={this.createNewPost} className={"btn btn-primary"} value={"Create"}/>
                    <input type={"button"} onClick={this.props.cancelCreateNewPost} className={"btn"} value={"Cancel"}/>
                </Modal.Footer>
            </Modal>
        );
    }
}

CreateNewPostPage.propTypes = {
    createNewHandler: PropTypes.func.isRequired,
    cancelCreateNewPost: PropTypes.func.isRequired,
    showCreateNewPost: PropTypes.bool.isRequired
};

export default CreateNewPostPage;