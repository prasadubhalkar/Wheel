import PropTypes from 'prop-types';
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as postManagementAction from '../../actions/postManagerActions';
import CreateNewPost from "./CreateNewPost";
import "./posts.scss";

class PostPage extends React.Component {
    constructor(context, props) {
        super(context, props);
        this.toggleShowCreateNewPost = this.toggleShowCreateNewPost.bind(this);
        this.handleCreateNewPost = this.handleCreateNewPost.bind(this);
        this.updateUserVote = this.updateUserVote.bind(this);
        this.addUserVote = this.addUserVote.bind(this);
        this.renderPostsTable = this.renderPostsTable.bind(this);
    }

    componentWillMount(){
        this.setState({
            showCreateNewPost: false
        });
        if(!this.props.selectedUserId) {
            window.location = "/";
        }
        else {
            this.props.actions.getPosts();
        }
    }

    toggleShowCreateNewPost() {
        this.setState({
            showCreateNewPost: !this.state.showCreateNewPost
        });
    }

    handleCreateNewPost(postData) {
        postData["ownerId"] = this.props.selectedUserId;
        this.props.actions.createPost(postData);
        this.toggleShowCreateNewPost();
    }

    postExpiredOrVotedFor(post) {
        if(post.hasExpired) {
            return true;
        }
        else if(post.votes && post.votes[this.props.selectedUserId] && !post.votes[this.props.selectedUserId+"_dirty"]){
            return true;
        }
        else if(!this.props.selectedUserId.trim()) {
            return false;
        }
        else {
            return false;
        }
    }

    findOptionVoteCount(post, inputOption) {
        let values = null;
        if(post && post.votes) {
            values = Object.values(post.votes);
            return values.reduce((count, option) => {
                if(option === inputOption){
                    count++;
                }
                return count;
            },0);
        }
        else {
            return 0;
        }
    }

    findMaxOption(post) {
        let totalVotes = {};
        let values = Object.values(post.votes);
        for(let i = 0; i < values.length; i++) {
            if(!totalVotes[values[i]]){
                totalVotes[values[i]] = 1;
            }
            else {
                totalVotes[values[i]] += 1;
            }
        }
        let votes = Object.values(totalVotes).sort();
        return votes[votes.length - 1];
    }

    determineIfPostWinner(post, option) {
        return (this.findOptionVoteCount(post, option) === this.findMaxOption(post));
    }

    updateUserVote(postIndex, selectedOption) {
        this.props.actions.updateUserVote(postIndex,this.props.selectedUserId, selectedOption);
    }

    addUserVote(postId, post) {
        let updatedPost = JSON.parse(JSON.stringify(post));
        delete updatedPost.votes[this.props.selectedUserId+"_dirty"];
        this.props.actions.updatePost(postId, updatedPost);
    }

    renderPostsTable() {
        let posts = this.props.posts;
        let self = this;
        return (
            <table className={"table table-striped"}>
                <thead>
                <tr>
                    <th>Post</th>
                    <th>Options</th>
                    <th>Expired / Expires in hours</th>
                    <th>Your Choice</th>
                </tr>
                </thead>
                <tbody>
                {
                    posts && posts.map((post, postIndex) => {
                        return <tr key={postIndex}>
                            <td>{post.name}</td>
                            <td>
                                <div className={"col-md-4"}>
                                    {post.options.map((option, optionIndex) => {
                                        return self.renderPostOption(post, postIndex, option, optionIndex);
                                    })}
                                </div>
                                {!post.hasExpired &&
                                    <button className={"btn btn-primary"}
                                            disabled={self.postExpiredOrVotedFor(post)}
                                            onClick={function(){
                                                self.addUserVote(post.id, post);
                                            }}>Vote</button>
                                }
                            </td>
                            <td>{(post.hasExpired) ? "Expired" : post.remainingHours}</td>
                            <td>{(post.votes && post.votes[this.props.selectedUserId]) ? post.votes[this.props.selectedUserId] : "Not voted yet"}</td>
                        </tr>;})
                }
                </tbody>
            </table>
        );
    }

    renderPostOption(post, postIndex, option, optionIndex) {
        let self = this;
        return (
            <div key={optionIndex} className="radio">
                <span className={(post.hasExpired && (self.determineIfPostWinner(post, option)) ? "label label-success": "span")}>
                    {!post.hasExpired && <input
                        type={"radio"}
                        name={post.id}
                        value={optionIndex}
                        onClick={function(){self.updateUserVote(postIndex , option);}}
                        disabled={self.postExpiredOrVotedFor(post)}
                    />} {option} </span>
            </div>
        );
    }

    render() {
        let showCreateNewPost = this.state.showCreateNewPost;
        return(
            <div className={"postContainer"}>
                <div className={"createNewPostWrapper row"}>
                    <input type={"button"} onClick={this.toggleShowCreateNewPost} className={"btn btn-primary"} value={"Add New Post"}/>
                </div>
                <CreateNewPost className={"row"}
                               createNewHandler={this.handleCreateNewPost}
                               cancelCreateNewPost={this.toggleShowCreateNewPost}
                               showCreateNewPost={showCreateNewPost}/>
                {this.renderPostsTable()}
            </div>
        );
    }
}

PostPage.propTypes = {
    posts: PropTypes.array,
    actions: PropTypes.object.isRequired,
    selectedUserId: PropTypes.string
};

function mapStateToProps(state) {
    return {
        loading: state.ajaxCallInProgress > 0,
        posts: state.postManager.posts,
        selectedUserId: state.userManager.userId
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(postManagementAction, dispatch)
    };
}
export default connect(mapStateToProps, mapDispatchToProps)(PostPage);
