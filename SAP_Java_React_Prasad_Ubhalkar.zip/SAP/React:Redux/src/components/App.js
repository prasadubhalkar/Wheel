import AppRoutes from './AppRoutes';
import React from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../node_modules/toastr/build/toastr.min.css';

class App extends React.Component {
    constructor(context, props) {
        super(context, props);
    }

    render() {
        return (
            <div className="container">
                <AppRoutes/>
            </div>
        );
    }
}

export default App;
