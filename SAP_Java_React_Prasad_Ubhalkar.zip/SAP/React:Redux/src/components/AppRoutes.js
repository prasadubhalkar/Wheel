import { BrowserRouter, Route } from 'react-router-dom';
import React from 'react';
import Posts from './Posts';
import Users from './Users';

class AppRoutes extends React.Component {
    render() {
        return (
            <BrowserRouter>
                <div>
                    <Route path="/" exact component={Users}/>
                    <Route path="/posts" component={Posts}/>
                </div>
            </BrowserRouter>
        );
    }
}

export default AppRoutes;
