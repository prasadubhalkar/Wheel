/* Ajax Status */
export const BEGIN_XHR_CALL = 'BEGIN_XHR_CALL';
export const ERROR_XHR_CALL = 'ERROR_XHR_CALL';

/* Post Action Details */
export const GET_ALL_POSTS = "LOAD_ALL_POSTS";
export const GET_POST = "GET_POST";
export const UPDATE_POST = "UPDATE_POST";
export const DELETE_POST = "DELETE_POST";
export const CREATE_POST = "CREATE_POST";
export const UPDATE_VOTES = "UPDATE_VOTES";

/* User Action Details */
export const CREATE_USER = "CREATE_USER";
export const GET_ALL_USERS = "GET_ALL_USERS";
export const SET_SELECTED_USER = "SET_SELECTED_USER";