import * as types from './actionTypes';
import usersManagement from '../services/userManagementService';
import {beginXhrCall, errorXhrCall} from './httpRequestActions';

export function dispatchLoadUsers(usersData) { return { type: types.GET_ALL_USERS, usersData }; }
export function dispatchSelectUsers(userId) { return { type: types.SET_SELECTED_USER, userId }; }
export function dispatchCreateNewUsers(usersData) { return { type: types.CREATE_USER, usersData }; }

export function getUsers() {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return usersManagement.getUsers().then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchLoadUsers(json));
                });
            }
        }).catch(error => {
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function createUser(userId, userBody) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return usersManagement.createUser(userId, userBody).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchCreateNewUsers(json));
                });
            }
        }).catch(error => {
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function setCurrentUser(userId) {
    return function(dispatch) {
        dispatch(dispatchSelectUsers(userId));
    };
}