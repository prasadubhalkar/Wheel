import * as types from './actionTypes';
import postManagement from '../services/postManagementService';
import {beginXhrCall, errorXhrCall} from './httpRequestActions';

export function dispatchLoadPosts(postData) { return { type: types.GET_ALL_POSTS, postData }; }
export function dispatchLoadPost(postData) { return { type: types.GET_POST, postData }; }
export function dispatchUpdatePost(postData) { return { type: types.UPDATE_POST, postData }; }
export function dispatchDeletePost(postData) { return { type: types.DELETE_POST, postData }; }
export function dispatchCreatePost(postData) { return { type: types.CREATE_POST, postData }; }
export function dispatchUpdateUserVote(postData) { return { type: types.UPDATE_VOTES,  postData }; }

export function getPosts() {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return postManagement.getPosts().then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchLoadPosts(json));
                });
            }
        }).catch(error => {
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function getPostData(postId) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return postManagement.getPost(postId).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchLoadPost(json));
                });
            }
        }).catch(error => {
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function updatePost(postId, postBody) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return postManagement.updatePost(postId, postBody).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchUpdatePost(json));
                });
            }
        }).catch(error => {
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function deletePost(postId) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return postManagement.deletePost(postId).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchDeletePost(json));
                });
            }
        }).catch(error => {
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function createPost(postBody) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return postManagement.createPost(postBody).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchCreatePost(json));
                });
            }
        }).catch(error => {
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function updateUserVote(postIndex, selectedUser, selectedOption) {
    let postData = {
        postIndex,
        selectedUser,
        selectedOption
    };
    return function(dispatch) {
        dispatch(dispatchUpdateUserVote(postData));
    };
}