import * as types from '../actions/actionTypes';
import initialState from './initialState';

export default function usersReducer(state = initialState.application, action) {
    switch (action.type) {
        case types.CREATE_USER:
        case types.GET_ALL_USERS:
            return Object.assign({}, state, {
                users: action.usersData
            });
        case types.SET_SELECTED_USER:
            return Object.assign({}, state, {
                userId: action.userId
            });
        default:
            return state;
    }
}