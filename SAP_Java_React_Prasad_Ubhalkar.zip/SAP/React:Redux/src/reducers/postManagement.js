import * as types from '../actions/actionTypes';
import initialState from './initialState';

export default function postsReducer(state = initialState.application, action) {
    let updatePosts = null;
    switch (action.type) {
        case types.CREATE_POST:
        case types.DELETE_POST:
        case types.GET_ALL_POSTS:
        case types.UPDATE_POST:
        case types.GET_POST:
            return Object.assign({}, state, {
                posts: action.postData
            });
        case types.UPDATE_VOTES:
            updatePosts = JSON.parse(JSON.stringify(state.posts));
            if(!updatePosts[action.postData.postIndex].votes){
                updatePosts[action.postData.postIndex]["votes"] = {};
            }
            updatePosts[action.postData.postIndex].votes[action.postData.selectedUser] = action.postData.selectedOption;
            updatePosts[action.postData.postIndex].votes[action.postData.selectedUser+"_dirty"] = true;
            return Object.assign({}, state, {
                posts: updatePosts
            });
        default:
            return state;
    }
}