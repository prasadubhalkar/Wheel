import {combineReducers} from 'redux';
import postManager from './postManagement';
import userManager from './userManagement';
const rootReducer = combineReducers({
    postManager,
    userManager
});

export default rootReducer;