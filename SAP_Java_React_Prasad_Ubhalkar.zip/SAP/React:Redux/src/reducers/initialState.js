export default {
    application: {
        posts: null,
        users: null,
        userId: ""
    },
    ajaxCallInProgress: 0
};