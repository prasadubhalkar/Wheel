package com.springboot.rest.controller;

import com.springboot.rest.model.Post;
import com.springboot.rest.service.PostsService;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import javax.inject.Inject;
import java.util.List;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/")
public class PostsController {

    @Inject
    private PostsService postsService;

    @RequestMapping(value = "posts", method = RequestMethod.GET)
    public List<Post> posts() {
        return postsService.posts();
    }

    @RequestMapping(value = "posts", method = RequestMethod.POST)
    public List<Post> create(@RequestBody Post post) {
        return postsService.create(post);
    }

    @RequestMapping(value = "posts/{id}", method = RequestMethod.PUT)
    public List<Post> update(@PathVariable Long id, @RequestBody Post post) {
        return postsService.update(id, post);
    }
}
