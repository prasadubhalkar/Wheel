package com.springboot.rest.service;

import com.springboot.rest.model.User;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
@Service
public interface UsersService {
    List<User> users();
    List<User> create(String userId, User user);
}
