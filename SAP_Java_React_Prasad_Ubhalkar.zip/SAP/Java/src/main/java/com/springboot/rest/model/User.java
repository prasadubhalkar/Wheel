package com.springboot.rest.model;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
public class User {
    //User Id
    private String userId;
    //User Name
    private String name;

    /**
     * Get User Id
     * @return
     */
    public String getId() {
        return userId;
    }

    /**
     * Set User Id
     * @param id
     */
    public void setId(String id) {
        this.userId = id;
    }

    /**
     * Get User Name
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Set User Name
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }
}
