package com.springboot.rest.model;

import java.util.Map;
import java.util.List;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
public class Post {
    //Post Id (is randomly generated
    private Long id;
    //Post Name
    private String name;
    //Duration valid for in hours
    private int duration;
    //Expiration time is calculated future date
    private String expirationTime;
    //Hasmap of votes from users
    private Map<String, String> votes;
    //Options for the Post (3 Max)
    private List<String> options;
    //Owner Id for the Post
    private String ownerId;
    //Remaning hours , calculated
    private String remainingHours;
    //Find if post has expired
    private boolean hasExpired;

    /**
     * Get post Id
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * Set post Id
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Get post name
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Set post name
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get post duration
     * @return
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Set post duration
     * @param duration
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * Get expiration date
     * @return
     */
    public String getExpirationTime() {
        return expirationTime;
    }

    /**
     * Set Expiration date
     * @param expirationTime
     */
    public void setExpirationTime(String expirationTime) {
        this.expirationTime = expirationTime;
    }

    /**
     * Get Votes for Post
     * @return
     */
    public Map<String, String> getVotes() {
        return votes;
    }

    /**
     * Set Votes for post
     * @param votes
     */
    public void setVotes(Map<String, String> votes) {
        this.votes = votes;
    }

    /**
     * Get post options (Max 3)
     * @return
     */
    public List<String> getOptions() {
        return options;
    }

    /**
     * Set post options (Max 3)
     * @param options
     */
    public void setOptions(List<String> options) {
        this.options = options;
    }

    /**
     * Get owner Id
     * @return
     */
    public String getOwnerId() {
        return ownerId;
    }

    /**
     * Set Owner Id
     * @param ownerId
     */
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    /**
     * Get remaning Hours
     * @return
     */
    public String getRemainingHours() {
        return remainingHours;
    }

    /**
     * Set remaning Hours
     * @param remainingHours
     */
    public void setRemainingHours(String remainingHours) {
        this.remainingHours = remainingHours;
    }

    /**
     * Gett post expiration
     * @return
     */
    public boolean isHasExpired() {
        return hasExpired;
    }

    /**
     * Set post expiration
     * @param hasExpired
     */
    public void setHasExpired(boolean hasExpired) {
        this.hasExpired = hasExpired;
    }
}
