package com.springboot.rest.service;

import java.util.Random;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
public final class Constants {
    //Random number upper limit
    private static final Long UPPER_LIMIT = 200L;
    //Random number lowe limit
    private static final Long LOWER_LIMIT = 100L;

    public static final int SIXTY_THOUSAND = 60000;

    public static final int SIXTY = 60;
    //create random number instance
    private static Random randomIdGenerator = new Random();
    //generate random number
    public static Long generateRandomNumber() {
        return LOWER_LIMIT + ((long) (randomIdGenerator.nextDouble() * (UPPER_LIMIT - LOWER_LIMIT)));
    }
}
