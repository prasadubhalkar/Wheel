package com.springboot.rest.service.impl;

import com.google.gson.Gson;
import com.springboot.rest.model.User;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
@Service
public class UsersServiceImpl {
    //Create a Static list accessible across application
    private List<User> usersList = new ArrayList<>();

    private URL url = PostsServiceImpl.class.getResource("Users.json");

    private final String filePath = url.getPath();

    /**
     * Reading from a JSON file
     * Users.json stored under the resources folder
     * NOTE: Might give issues with access use absolute path if needed
     * @return
     */
    private JSONArray getUserData() {
        JSONArray jsonArray = null;
        try {
            JSONParser parser = new JSONParser();
            InputStream inputStream = new FileInputStream(filePath);
            Reader fileReader = new InputStreamReader(inputStream, "UTF-8");
            jsonArray = (JSONArray) parser.parse(fileReader);
        }
        catch (org.json.simple.parser.ParseException ex) {
            //TODO integrate logger
        }
        catch (FileNotFoundException e) {
            //TODO integrate logger
        }
        catch (UnsupportedEncodingException uee) {
            //TODO integrate logger
        }
        catch (IOException io) {
            //TODO integrate logger
        }
        return jsonArray;
    }

    /**
     * Will parse the JSON file and load users
     * from the file to serve in REST API
     * @param jsonArray
     * @return
     */
    private List<User> addUsers(JSONArray jsonArray) {
        for (Object object : jsonArray) {
            JSONObject jsonObject = (JSONObject) object;
            String userId = (String) jsonObject.get("userId");
            String ownerName = (String) jsonObject.get("name");
            User user = new User();
            user.setName(ownerName);
            user.setId(userId);
            usersList.add(user);
        }
        return usersList;
    }

    /**
     * Will update the JSON file with new list of users
     * Called whenever a new user is added / registered
     * @return
     */
    private Boolean updateJsonFiles() {
        try {
            OutputStream outputStream = new FileOutputStream(filePath);
            Writer userWriter = new OutputStreamWriter(outputStream, "UTF-8");
            Gson gson = new Gson();
            String json = gson.toJson(usersList);
            userWriter.write(json);
            userWriter.flush();
            userWriter.close();
            return true;
        }
        catch (IOException io) {
            return false;
        }
    }

    /**
     * Will take in userId and User details
     * for the new user , add it to the user list
     * and push it to the file
     * @param userId
     * @param user
     * @return
     */
    public List<User> create(String userId, User user) {
        user.setId(userId);
        usersList.add(user);
        updateJsonFiles();
        return usersList;
    }

    /**
     * if user list does not have any data
     * initially load it from the file and return it to
     * get users call
     * @return
     */
    public List<User> users() {
        if (usersList.size() <= 0) {
            return addUsers(getUserData());
        }
        else {
            return usersList;
        }
    }
}
