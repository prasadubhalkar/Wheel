package com.springboot.rest.service.impl;

import com.google.gson.Gson;
import com.springboot.rest.model.Post;
import com.springboot.rest.service.Constants;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
@Service
public class PostsServiceImpl {
    //Will create and maintain single posts list across application (reason for going static)
    private List<Post> postsList = new ArrayList<>();

    private URL url = PostsServiceImpl.class.getResource("Posts.json");

    private final String filePath = url.getPath();

    /**
     * This function will get all the posts
     * stored under the file Posts.json
     * NOTE: Might give issues with accessing file path
     * use absolute if needed with required permissions
     * @return
     */
    private JSONArray getPostsData() {
        JSONArray jsonArray = null;
        try {
            JSONParser parser = new JSONParser();
            InputStream inputStream = new FileInputStream(filePath);
            Reader fileReader = new InputStreamReader(inputStream, "UTF-8");
            jsonArray = (JSONArray) parser.parse(fileReader);
        }
        catch (org.json.simple.parser.ParseException ex) {
            //TODO integrate logger
        }
        catch (FileNotFoundException e) {
            //TODO integrate logger
        }
        catch (UnsupportedEncodingException uee) {
            //TODO integrate logger
        }
        catch (IOException io) {
            //TODO integrate logger
        }
        return jsonArray;
    }

    /**
     * Will add a posts from the JSON array
     * to the list
     * @param jsonArray
     * @return
     */
    private List<Post> addPosts(JSONArray jsonArray) {
        for (Object object : jsonArray) {
            JSONObject jsonObject = (JSONObject) object;
            long postId = (long) jsonObject.get("id");
            String postName = (String) jsonObject.get("name");
            long postDuration = (long) jsonObject.get("duration");
            String postExpirationDate = (String) jsonObject.get("expirationTime");
            Map<String, String> postVotes = (HashMap<String, String>) jsonObject.get("votes");
            List<String> postOptions = (ArrayList<String>) jsonObject.get("options");
            String ownerId = (String) jsonObject.get("ownerId");
            Boolean hasExpired = (Boolean) jsonObject.get("hasExpired");

            Post post = new Post();
            post.setId(postId);
            post.setOwnerId(ownerId);
            post.setName(postName);
            post.setDuration((int) postDuration);
            post.setVotes(postVotes);
            post.setExpirationTime(postExpirationDate);
            post.setHasExpired(hasExpired);
            post.setOptions(postOptions);

            postsList.add(post);
        }
        return postsList;
    }

    /**
     * Will calculate remaning hours on the post
     * and mark it as expired if needed
     * @param post
     * @return
     */
    private Post calculateRemaningHours(Post post) {
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        try {
            if (!post.isHasExpired()) {
                long dateDiff = ((df.parse(post.getExpirationTime()).getTime() - new Date().getTime()) / Constants.SIXTY_THOUSAND) / Constants.SIXTY;
                if (dateDiff < 0) {
                    post.setHasExpired(true);
                }
                post.setRemainingHours("" + dateDiff);
            }
        }
        catch (ParseException pe) {
            //TODO integrate logger
        }
        return post;
    }

    /**
     * Will get the list of posts
     * and also pre-process to find
     * any expired post
     * @return
     */
    public List<Post> posts() {
        if (postsList.size() <= 0) {
            addPosts(getPostsData());
        }
        for (int i = 0; i < postsList.size(); i++) {
            postsList.set(i, calculateRemaningHours(postsList.get(i)));
        }
        return postsList;
    }

    /**
     * Will create a new post and add it to list
     * and initiate the call to store / update the JSON
     * @param post
     * @return
     */
    public List<Post> create(Post post) {
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, post.getDuration());
        post.setExpirationTime(df.format(cal.getTime()));
        post.setId(Constants.generateRandomNumber());
        postsList.add(calculateRemaningHours(post));
        updateJsonFiles();
        return postsList;
    }

    /**
     * Will write the updated JSON array content
     * to the JSON file
     * @return
     */
    private Boolean updateJsonFiles() {
        try {
            OutputStream outputStream = new FileOutputStream(filePath);
            Writer postWriter = new OutputStreamWriter(outputStream, "UTF-8");
            Gson gson = new Gson();
            String json = gson.toJson(postsList);
            postWriter.write(json);
            postWriter.flush();
            postWriter.close();
            return true;
        }
        catch (IOException io) {
            //TODO add logger
            return false;
        }
    }

    /**
     * Will update the existing post with newly added
     * votes
     * @param postId
     * @param inputPost
     * @return
     */
    public List<Post> update(Long postId, Post inputPost) {
        for (int i = 0; i < postsList.size(); i++) {
            if (postsList.get(i).getId().equals(postId)) {
                postsList.set(i, calculateRemaningHours(inputPost));
            }
        }
        updateJsonFiles();
        return postsList;
    }
}
