package com.springboot.rest.service;

import com.springboot.rest.model.Post;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
@Service
public interface PostsService {
    List<Post> update(Long postId, Post inputPost);
    List<Post> create(Post post);
    List<Post> posts();
}
