package com.springboot.rest.controller;

import com.springboot.rest.model.User;

import com.springboot.rest.service.UsersService;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import javax.inject.Inject;
import java.util.List;

/**
 * Created by Prasad Ubhalkar on 10/28/17.
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/")
public class UsersController {
    @Inject
    private UsersService usersService;

    @RequestMapping(value = "users", method = RequestMethod.GET)
    public List<User> users() {
        return usersService.users();
    }

    @RequestMapping(value = "users/{id}", method = RequestMethod.PUT)
    public List<User> create(@PathVariable String id, @RequestBody User user) {
        return usersService.create(id, user);
    }
}
