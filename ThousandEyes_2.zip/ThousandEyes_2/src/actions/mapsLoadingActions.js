import * as types from './actionTypes';
import LoadGeoJson from "../services/LoadGeoJson";
import { ajaxCallError } from "./httpRequestAction";

export function dispatchStreetDataLoaded(streetJson) { return { type: types.LOAD_STREET_JSON, streetJson }; }
export function dispatchArteriesDataLoaded(arterisJson) { return { type: types.LOAD_ARTERIES_JSON, arterisJson }; }
export function dispatchFreewaysDataLoaded(freewayJson) { return { type: types.LOAD_FREEWAYS_JSON, freewayJson }; }
export function dispatchNeighborhoodsDataLoaded(neighbirhoodJson) { return { type: types.LOAD_NEIGHBORHOODS_JSON, neighbirhoodJson }; }


/**
 * Ajax Request to load Streets Geo Json
 * @returns {Function}
 */
export function loadStreetsData() {
    return function(dispatch) {
        return LoadGeoJson.getJsonData('./sfmaps/streets.json').then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchStreetDataLoaded(json));
                });
            }
            else {
                dispatch(ajaxCallError("Failed to load streets data"));
            }
        }).catch(error => {
            dispatch(ajaxCallError(error.message));
            throw(error);
        });
    };
}

/**
 * Ajax Request to load Arteries Geo Json
 * @returns {Function}
 */
export function loadArteriesData() {
    return function(dispatch) {
        return LoadGeoJson.getJsonData('./sfmaps/arteries.json').then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchArteriesDataLoaded(json));
                });
            }
            else {
                dispatch(ajaxCallError("Failed to load arteries data"));
            }
        }).catch(error => {
            dispatch(ajaxCallError(error.message));
            throw(error);
        });
    };
}

/**
 * Ajax Request to load Freeways Geo Json
 * @returns {Function}
 */
export function loadFreewaysData() {
    return function(dispatch) {
        return LoadGeoJson.getJsonData('./sfmaps/freeways.json').then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchFreewaysDataLoaded(json));
                });
            }
            else {
                dispatch(ajaxCallError("Failed to load freeways data"));
            }
        }).catch(error => {
            dispatch(ajaxCallError(error.message));
            throw(error);
        });
    };
}

/**
 * Ajax Request to load Neighborhoods Geo Json
 * @returns {Function}
 */
export function loadNeighborhoodsData() {
    return function(dispatch) {
        return LoadGeoJson.getJsonData('./sfmaps/neighborhoods.json').then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchNeighborhoodsDataLoaded(json));
                });
            }
            else {
                dispatch(ajaxCallError("Failed to load neighborhoods data"));
            }
        }).catch(error => {
            dispatch(ajaxCallError(error.message));
            throw(error);
        });
    };
}