/**
 * Ajax Request Constants
 * @type {string}
 */
export const BEGIN_AJAX_CALL = 'BEGIN_AJAX_CALL';
export const AJAX_CALL_ERROR = 'AJAX_CALL_ERROR';
export const AJAX_CALL_SUCCESS = 'AJAX_CALL_SUCCESS';

/**
 * Map Geo JSON constants
 * @type {string}
 */
export const LOAD_STREET_JSON = 'LOAD_STREET_JSON';
export const LOAD_ARTERIES_JSON = 'LOAD_ARTERIES_JSON';
export const LOAD_FREEWAYS_JSON = 'LOAD_FREEWAYS_JSON';
export const LOAD_NEIGHBORHOODS_JSON = 'LOAD_NEIGHBORHOODS_JSON';

/**
 * Next Bus and Position availability Constants
 * @type {string}
 */
export const LOAD_MUNI_DATA = 'LOAD_MUNI_DATA';
export const UPDATE_VEHICLE_LOCATION = 'UPDATE_VEHICLE_LOCATION';
export const LOAD_MUNI_ROUTES = 'LOAD_MUNI_ROUTES';
export const UPDATE_MUNI_ROUTE = 'UPDATE_MUNI_ROUTE';