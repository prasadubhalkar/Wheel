import * as types from './actionTypes';
import MuniDataService from "../services/GetMuniData";
import { beginAjaxCall, ajaxCallError } from "./httpRequestAction";

export function dispatchMuniDataLoaded(muniData) { return { type: types.LOAD_MUNI_DATA, muniData }; }
export function dispatchVehicleLocationData(locationData) { return { type: types.UPDATE_VEHICLE_LOCATION, locationData }; }
export function dispatchMuniRoutes(routes) { return { type: types.LOAD_MUNI_ROUTES, routes}; }
export function dispatchUpdatedRoute(updatedRoute) { return { type: types.UPDATE_MUNI_ROUTE, updatedRoute}; }

/**
 * Get the default route list data
 * @returns {Function}
 */
export function loadMuniData() {
    return function(dispatch) {
        dispatch(beginAjaxCall());
        return MuniDataService.getSFMuniNList().then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchMuniDataLoaded(json));
                });
            }
            else {
                dispatch(ajaxCallError("Failed to fetch default route list"));
            }
        }).catch(error => {
            dispatch(ajaxCallError(error.message));
            throw(error);
        });
    };
}

/**
 * Load Vehicle Data for selected route
 * @param routeName - Route for which vehicle data is to be loaded
 * @returns {Function}
 */
export function loadVehicleLocationData(routeName) {
    return function(dispatch) {
        dispatch(beginAjaxCall());
        return MuniDataService.getVehicleLocation(routeName).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchVehicleLocationData(json));
                });
            }
            else {
                dispatch(ajaxCallError("Failed to fetch vehicle data for " + routeName));
            }
        }).catch(error => {
            dispatch(ajaxCallError(error.message));
            throw(error);
        });
    };
}

/**
 * Get the list of SF-MUNI routes
 * @returns {Function}
 */
export function loadMuniRoutes() {
    return function(dispatch) {
        dispatch(beginAjaxCall());
        return MuniDataService.getRoutes().then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(dispatchMuniRoutes(json));
                });
            }
            else {
                dispatch(ajaxCallError("Failed to load list route list"));
            }
        }).catch(error => {
            dispatch(ajaxCallError(error.message));
            throw(error);
        });
    };
}

/**
 * Change and Update the default route in Store
 * @param changedRoute - new route
 * @returns {Function}
 */
export function changeDefaultRoute(changedRoute) {
    return function(dispatch) {
        dispatch(dispatchUpdatedRoute(changedRoute));
    };
}


