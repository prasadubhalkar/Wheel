export const PROJECTION_SCALE = 300000;
export const CENTER_LAT = -122.50;
export const CENTER_LON = 37.75;
export const SCALE_EXTENT_LAT = -1;
export const SCALE_EXTENT_LON = 2;