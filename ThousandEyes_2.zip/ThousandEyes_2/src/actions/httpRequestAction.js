import * as types from './actionTypes';

/**
 * Will be invoked whenever we are making
 * an XML HTTP Request / Ajax call to fetch
 * data
 * @returns {{type}}
 */
export function beginAjaxCall() {
    return { type: types.BEGIN_AJAX_CALL };
}

/**
 * Will be invoked whenever the backend or
 * XML HTTP Request / Ajax call fails
 * @param error
 * @returns {{type}}
 */
export function ajaxCallError(error) {
    return { type: types.AJAX_CALL_ERROR, error };
}
