/*eslint-disable import/default */
import React from 'react';
import {render} from 'react-dom';
import App from './components/App';
import {Provider} from 'react-redux';
import configureStore from './store/configureServer';

import './styles/styles.scss';
import '../node_modules/toastr/build/toastr.min.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

const store = configureStore();
render(
    <Provider store={store}>
        <App/>
    </Provider>,
    document.getElementById('app')
);
