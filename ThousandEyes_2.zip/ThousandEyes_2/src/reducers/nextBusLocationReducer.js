import * as types from '../actions/actionTypes';
import initialState from './initialState';

/**
 * Will listen to the Vehicle and Route Change
 * and update the store
 * @param state
 * @param action
 * @returns {*}
 */
export default function nextBusReducer(state = initialState.nextBusLocation, action) {
    switch (action.type) {
        case types.LOAD_MUNI_DATA:
            return Object.assign({}, state, {
                muniData: action.muniData
            });
        case types.UPDATE_VEHICLE_LOCATION:
            return Object.assign({}, state, {
                vehicleLocations: action.locationData
            });
        case types.LOAD_MUNI_ROUTES:
            return Object.assign({}, state, {
                routesList: action.routes
            });
        case types.UPDATE_MUNI_ROUTE:
            return Object.assign({}, state, {
                selectedRoute: action.updatedRoute
            });
        default:
            return state;
    }
}