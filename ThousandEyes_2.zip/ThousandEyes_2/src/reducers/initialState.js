export default {
    jsonMapData: {
        streetsJson: null,
        arteriesJson: null,
        freewaysJson: null,
        neighborhoodsJson: null
    },
    httpRequestStatus: {
        requestInProgress: false,
        requestFailed: false,
        errorMessage: null
    },
    nextBusLocation: {
        muniData: null,
        vehicleLocations: null,
        routesList: null,
        selectedRoute: "N"
    }
};
