import {combineReducers} from 'redux';
import httpService from './httpRequestReducer';
import geoJson from './mapLoadingReducer';
import busRoute from './nextBusLocationReducer';

/**
 * Combine the Reducers
 * @type {Reducer<any>}
 */
const rootReducer = combineReducers({
    httpService,
    geoJson,
    busRoute
});

export default rootReducer;