import * as types from '../actions/actionTypes';
import initialState from './initialState';

/**
 * This is the XML HTTP Request Reducer
 * Which will manage and Change the state
 * based on Request progress status
 * @param state Application State
 * @param action Ajax Request Action (httpRequestAction)
 * @returns {*}
 */
export default function httpRequestReducer(state = initialState.httpRequestStatus, action) {
    switch (action.type) {
        case types.BEGIN_AJAX_CALL:
            return Object.assign({}, state, {
                requestInProgress: true
            });
        case types.AJAX_CALL_ERROR:
            return Object.assign({}, state, {
                requestFailed: true,
                requestInProgress: false,
                errorMessage: action.error
            });
        case types.AJAX_CALL_SUCCESS:
            return Object.assign({}, state, {
                requestInProgress: false
            });
        default:
            return state;
    }
}