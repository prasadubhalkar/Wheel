import * as types from '../actions/actionTypes';
import initialState from './initialState';

/**
 * Will listen for the GeoMap loads
 * and update the store
 * @param state
 * @param action
 * @returns {*}
 */
export default function loadJsonData(state = initialState.jsonMapData, action) {
    switch (action.type) {
        case types.LOAD_STREET_JSON:
            return Object.assign({}, state, {
                streetsJson: action.streetJson
            });
        case types.LOAD_NEIGHBORHOODS_JSON:
            return Object.assign({}, state, {
                neighborhoodsJson: action.neighbirhoodJson
            });
        case types.LOAD_FREEWAYS_JSON:
            return Object.assign({}, state, {
                freewaysJson: action.freewayJson
            });
        case types.LOAD_ARTERIES_JSON:
            return Object.assign({}, state, {
                arteriesJson: action.arterisJson
            });
        default:
            return state;
    }
}