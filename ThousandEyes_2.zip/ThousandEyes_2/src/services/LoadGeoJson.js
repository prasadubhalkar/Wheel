/**
 * Will load the GeoJSON files
 */
class LoadGeoJson {
    /**
     * Load the GeoJson files
     * @param jsonFilePath
     * @returns {*}
     */
    static getJsonData(jsonFilePath) {
        return fetch(jsonFilePath);
    }
}

export default LoadGeoJson;
