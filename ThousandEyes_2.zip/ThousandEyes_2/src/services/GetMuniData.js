class GetMuniData {
    /**
     * Fetch Muni Route Information
     * @returns {*}
     */
    static getSFMuniNList() {
        return fetch(
            process.env.APIENPOINT + '?command=routeConfig&a=sf-muni&r=N',
            {
                method: "GET",
                headers: {
                    Accept: "application/json"
                }
            }
        );
    }

    /**
     * Fetch the Vehicle location for Selected Route
     * @param routeName
     * @returns {*}
     */
    static getVehicleLocation(routeName) {
        return fetch(
            process.env.APIENPOINT + '?command=vehicleLocations&a=sf-muni&r='+routeName+'&t=20',
            {
                method: "GET",
                headers: {
                    Accept: "application/json"
                }
            }
        );
    }

    /**
     * Get the Route list for MUNI
     * @returns {*}
     */
    static getRoutes() {
        return fetch(
            process.env.APIENPOINT + '?command=routeList&a=sf-muni',
            {
                method: "GET",
                headers: {
                    Accept: "application/json"
                }
            }
        );
    }
}

export default GetMuniData;
