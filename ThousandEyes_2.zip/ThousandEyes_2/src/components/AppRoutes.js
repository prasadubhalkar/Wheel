import React from 'react';
import { Route, withRouter, Switch } from 'react-router-dom';

//Routing Components
import Home from './Home';

/**
 * Application Router
 */
class AppRoutes extends React.Component {
    render() {
        return (
            <div>
                <div className="page-container">
                    <Switch>
                        <Route exact path="/" component={Home}/>
                    </Switch>
                </div>
            </div>
        );
    }
}

export default withRouter(AppRoutes);
