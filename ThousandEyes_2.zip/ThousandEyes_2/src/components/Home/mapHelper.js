import * as constants from '../../actions/appConstants';

/**
 * Will use the D3 library for
 * rendering map on the component
 */
export default class MapHelper {
    /**
     * initiate and projection
     * svg and behavior of D3
     */
    constructor() {
        this.path = null;
        this.svg = null;
        this.projection = null;
        this.initProjection();
        this.intPath();
        this.initBehavior();
    }

    /**
     * Create and return projection
     * @returns {null|*}
     */
    initProjection() {
        this.projection = window.d3.geo.mercator()
            .scale(constants.PROJECTION_SCALE)
            .center([constants.CENTER_LAT, constants.CENTER_LON]);
        return this.projection;
    }

    /**
     * Create and return geoPath
     * @returns {null|*}
     */
    intPath() {
        this.path = window.d3.geo.path().projection(this.projection);
        return this.path;
    }

    /**
     * Create and return
     * D3 Behavior
     */
    initBehavior() {
        return window.d3.behavior
            .zoom()
            .scaleExtent([constants.SCALE_EXTENT_LAT, constants.SCALE_EXTENT_LON]);
    }

    /**
     * Append svg to specified
     * class Name
     * @param className
     * @returns {null|*}
     */
    appendSvg(className) {
        this.svg = window.d3.select("." + className).append("svg");
        return this.svg;
    }

    /**
     * Render path under svg
     * @param className class name for the path
     * @param pathData json for the geo path
     */
    renderPath(className, pathData) {
        this.svg.append('path')
            .datum(pathData)
            .attr('class', 'map ' + className)
            .style('fill', 'none')
            .attr('d', this.path);
    }

    /**
     * Will take in the vehicle data
     * and normalize it with Latitude and longitude
     * @param vehicleData
     */
    renderVehicleLocation(vehicleData) {
        let normalizedData = this.normalizeLocationData(vehicleData);
        this.renderVehiclePosition(this.svg.selectAll('circle').data(normalizedData));
    }

    /**
     * Will normalize the array
     * @param vehicleData
     * @returns {Array}
     */
    normalizeLocationData(vehicleData) {
        let normalizedLocationData = [];

        if(vehicleData.hasOwnProperty("vehicle") && vehicleData.vehicle.length) {
            vehicleData.vehicle.map((vehicle)=>{
                vehicle.coordinates = this.projection([vehicle.lon, vehicle.lat]);
                normalizedLocationData.push(vehicle);
            });
        }

        return normalizedLocationData;
    }

    /**
     * Will take the vehicle data and render
     * the vehicle location
     * @param vehicleLocations
     */
    renderVehiclePosition(vehicleLocations) {
        vehicleLocations.transition()
            .duration(500)
            .attr('cx', function(d) { return d.coordinates[0]; })
            .attr('cy', function(d) { return d.coordinates[1]; })
            .attr('r', 5)
            .style('stroke', function(d) { return "#6495ED"; })
            .style('stroke-width', 2)
            .style('fill', '#1E90FF');

        vehicleLocations.enter().append('circle').append("svg:title")
            .text(function(d) {
                return d.id + ' to ' + d.dirTag;
            });

        vehicleLocations.exit().remove();
    }

    /**
     * Render interpolation line
     * on the map
     * @param projection
     */
    drawLineInterpolation(projection) {
        window.d3.svg.line().x(function(d) { return projection([d.lon,d.lat])[0]; })
            .y(function(d) { return projection([d.lon,d.lat])[1]; })
            .interpolate('linear');
    }

    /**
     * will render the selected route
     * on the page
     * @param routePath
     */
    routePathRenderer(routePath) {
        let self = this;
        this.svg.append('path')
            .attr("d", self.drawLineInterpolation(self.projection)(routePath.point))
            .attr("class", "route" )
            .attr("data-tag", routePath.tag)
            .attr("data-tag", routePath.tag)
            .attr("stroke", '#ff0')
            .attr("stroke-width", 2)
            .style("stroke-opacity", 0.5)
            .attr("fill", "none")
            .append("svg:title")
            .text(function(d) {
                return routePath.title;
            });
    }
}
