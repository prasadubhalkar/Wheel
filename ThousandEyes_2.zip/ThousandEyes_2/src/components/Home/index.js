import React, {PropTypes} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
//render helpers
import MapHelper from './mapHelper';
//action and store update helpers
import * as geoJsonService from '../../actions/mapsLoadingActions';
import * as routeService from '../../actions/nextBusLocationActions';
import * as httpStatus from '../../actions/httpRequestAction';
//css for component
import './index.scss';

/**
 * Muni map will render the map using Maphelper
 * class
 */
class MuniMap extends React.Component {
    /**
     * Constructor for Home Page component
     * @param context - Takes in App Context
     * @param props - Takes in Component Props
     */
    constructor(context, props) {
        //call super with context and props
        super(context, props);

        //create a placeholder for d3
        this.path = null;
        this.svg = null;
        this.projection = null;

        //bind methods to this (component) scope
        this.onRouteChange = this.onRouteChange.bind(this);
    }

    /**
     * Triggered once when before component
     * is rendered on the screen
     */
    componentWillMount() {
        let self = this;
        //set the value for the drop down to default route (which in this case is N)
        this.setState({
            selectedRoute: "default",
            allMapDataLoaded: false
        });

        this.mapHelper = new MapHelper();
    }

    /**
     * Triggered once after component is
     * being rendered on the screen
     */
    componentDidMount() {
        let self = this;

        //when component mounted (rendered) use d3 to select the map-container class element
        //and append a svg
        this.svg = this.mapHelper.appendSvg("map-container");

        // make a request to fetch and load the geo map features
        this.props.actions.loadStreetsData();
        this.props.actions.loadArteriesData();
        this.props.actions.loadFreewaysData();
        this.props.actions.loadNeighborhoodsData();
        this.props.routeActions.loadMuniRoutes();
        this.props.routeActions.loadVehicleLocationData(this.props.selectedRoute);

        //set an interval which will load the current selected
        //SF MUNI bus route from route list and load that route on page
        setInterval(()=>{
            self.props.routeActions.loadVehicleLocationData(self.props.selectedRoute);
        }, 15000);
    }

    /**
     * Function is executed when props are being updated
     * due to store update
     * @param updatedProps - here are the next props loaded
     */
    componentWillReceiveProps(updatedProps) {
        //on re-render if street json is different
        if(updatedProps.streetsJson !== this.props.streetsJson) {
            this.mapHelper.renderPath('streets', updatedProps.streetsJson);
        }
        //on re-render if freeways json is different
        if(updatedProps.freewaysJson !== this.props.freewaysJson) {
            this.mapHelper.renderPath('freeways', updatedProps.freewaysJson);
        }
        //on re-render if arteries json is different
        if(updatedProps.arteriesJson !== this.props.arteriesJson) {
            this.mapHelper.renderPath('arteries', updatedProps.arteriesJson);
        }
        //on re-render if neighborhoods json is different
        if(updatedProps.neighborhoodsJson !== this.props.neighborhoodsJson) {
            this.mapHelper.renderPath('neighborhoods', updatedProps.neighborhoodsJson);
        }

        this.verifyGeoMapDataLoaded();

        // re-render the routes if routes data has changed
        if(updatedProps.currentRouteData !== this.props.currentRouteData) {
            this.mapHelper.routePathRenderer(updatedProps.currentRouteData);
        }
        // re-render the vehicle locations if it is changed
        if(updatedProps.vehicleLocations !== this.props.vehicleLocations) {
            this.mapHelper.renderVehicleLocation(updatedProps.vehicleLocations);
        }
    }

    /**
     * Verify if all needed
     * geo json data is loaded
     * @returns {boolean}
     */
    verifyGeoMapDataLoaded() {
        if(this.props.neighborhoodsJson &&
            this.props.arteriesJson &&
            this.props.freewaysJson &&
            this.props.streetsJson) {
            this.setState({
                allMapDataLoaded: true
            });
        }
        else {
            this.setState({
                allMapDataLoaded: false
            });
        }
    }

    /**
     * This is the change listener
     * function which will update the store
     * with changed route
     * @param event
     */
    onRouteChange(event) {
        let selectedValue = event.target.options[event.target.selectedIndex].value;
        this.setState({
            selectedRoute: selectedValue
        });
        this.props.routeActions.changeDefaultRoute(selectedValue);
        this.props.routeActions.loadVehicleLocationData(selectedValue);
    }

    /**
     * Render function will render
     * the map on Page
     * @returns {JSX}
     */
    render() {
        let routesList = null;
        let selectedRoute = this.state.selectedRoute;
        let allGeoMapsLoaded = this.state.allMapDataLoaded;
        let requestFailure = this.props.requestFailed;
        let requestErrorMessage = this.props.errorMessage;
        if(this.props.routesList) {
            routesList = this.props.routesList.route;
        }
        return (
            <div className={"home-component"}>
                {requestFailure && <div className="alert alert-danger"> <strong>Request Failed </strong> { requestErrorMessage } </div> }
                {!allGeoMapsLoaded && <div><span className="loader"/><i>Loading...</i></div>}
                <div className="form-group">
                    <label htmlFor="routesList">Select Route </label>
                    <select className="form-control"
                            id="routesList"
                            value={selectedRoute}
                            onChange={this.onRouteChange}>
                        <option value="default" disabled>{"Please select route (default N)"}</option>
                        {routesList && routesList.length && routesList.map((route, index) => {
                            return <option key={index} value={route.tag}>{route.title}</option>;
                        })}
                    </select>
                </div>
                <div className="map-container">{""}</div>
            </div>
        );
    }
}

/**
 * Render the Proptypes
 */
MuniMap.propTypes = {
    actions: PropTypes.object.isRequired,
    routeActions: PropTypes.object.isRequired,
    httpStatus: PropTypes.object.isRequired,
    streetsJson: PropTypes.object,
    arteriesJson: PropTypes.object,
    freewaysJson: PropTypes.object,
    neighborhoodsJson: PropTypes.object,
    currentRouteData: PropTypes.object,
    vehicleLocations: PropTypes.object,
    selectedRoute: PropTypes.string,
    requestFailed: PropTypes.bool,
    routesList: PropTypes.object,
    errorMessage: PropTypes.string,
    ajaxCallInProgress: PropTypes.bool
};

/**
 * Will map the states to props
 * @param state
 * @returns Object of Props
 */
function mapStateToProps(state) {
    return {
        streetsJson: state.geoJson.streetsJson,
        arteriesJson: state.geoJson.arteriesJson,
        freewaysJson:  state.geoJson.freewaysJson,
        neighborhoodsJson: state.geoJson.neighborhoodsJson,
        currentRouteData: state.busRoute.muniData,
        vehicleLocations: state.busRoute.vehicleLocations,
        selectedRoute: state.busRoute.selectedRoute,
        routesList: state.busRoute.routesList,
        errorMessage: state.httpService.errorMessage,
        ajaxCallInProgress: state.httpService.ajaxCallInProgress,
        requestFailed: state.httpService.requestFailed
    };
}

/**
 * Will map the actions to component props
 * @param dispatch
 * @returns Object of connected actions
 */
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(geoJsonService, dispatch),
        routeActions: bindActionCreators(routeService, dispatch),
        httpStatus: bindActionCreators(httpStatus, dispatch)
    };
}
//export connected component
export default connect(mapStateToProps, mapDispatchToProps) (MuniMap);