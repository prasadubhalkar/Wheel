import React from 'react';
import AppRoutes from './AppRoutes';
import { BrowserRouter } from 'react-router-dom';

/**
 * Parent App component
 */
class App extends React.Component {
    render() {
        return (
            <div className="container">
                <BrowserRouter>
                    <AppRoutes/>
                </BrowserRouter>
            </div>
        );
    }
}

export default App;
