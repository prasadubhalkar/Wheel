const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = function(env) {
    return {
        entry: path.resolve(__dirname, '../src/index'),
        target: 'web',
        output: {
            path: path.resolve(__dirname, '../dist'),
            publicPath: '/',
            filename: 'bundle.js'
        },
        plugins: [
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, '../src/index.html'),
                title: "Muni Map"
            }),
            new CopyWebpackPlugin([
                {
                    from: path.resolve(__dirname, '../sfmaps/**'),
                    to: path.resolve(__dirname, '../dist/')
                },
                {
                    from: path.resolve(__dirname, '../libs/d3.js'),
                    to: path.resolve(__dirname, '../dist/d3.js')
                }
            ])
        ],
        module: {
            loaders: [
                {
                    test: /\.js$/,
                    include: path.join(__dirname, '../src'),
                    loaders: ['babel-loader']
                },
                {
                    test: /credentials|\.eot|jpg|png|jpeg|gif(\?v=\d+\.\d+\.\d+)?$/,
                    loader: 'file-loader'
                },
                {
                    test: /\.(woff|woff2)$/,
                    loader: 'url-loader?prefix=font/&limit=5000'
                },
                {
                    test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
                    loader: 'url-loader?limit=10000&mimetype=application/octet-stream'
                },
                {
                    test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
                    loader: 'file-loader?name=assets/[name].[ext]'
                },
                {
                    test: /(\.css)$/,
                    loaders: ['style-loader', 'css-loader']
                },
                {
                    test: /(\.scss|\.sass)$/,
                    loaders: ['style-loader', 'css-loader', 'sass-loader']
                }
            ]
        }
    };
};
