const webpack = require('webpack');
const webpackMerge = require('webpack-merge');
const commonConfig = require('./commonConfig');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const GLOBALS = {
    ENV: "development",
    APIENPOINT: "http://webservices.nextbus.com/service/publicJSONFeed",
    NODE_ENV: "development"
};
module.exports = function() {
    return webpackMerge(commonConfig(GLOBALS.ENV), {
        devtool: 'inline-source-map',
        entry: path.resolve(__dirname, '../src/index'),
        target: 'web',
        plugins: [
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, '../src/index.html'),
                title: "SF Muni Map"
            }),
            new webpack.HotModuleReplacementPlugin(),
            new webpack.DefinePlugin({
                'process.env': {
                    'ENV': JSON.stringify(GLOBALS.ENV),
                    'APIENPOINT': JSON.stringify(GLOBALS.APIENPOINT)
                }
            })
        ],
        devServer: {
            contentBase: path.resolve(__dirname, '../src'),
            port: 3000,
            host: "localhost",
            historyApiFallback: true,
            watchOptions: {
                aggregateTimeout: 300,
                poll: 1000
            }
        }
    });
};
