# Thousand Eyes (MUNI Map assignment)

  ## Install Node and global packages
    Install node version >= 5.0
    To check node version on your machine use node -v from terminal

    Run "npm install yarn -g" to install yarn globally on your machine
    Verify installation by running yarn --help

  ## Project Setup
    Navigate to the project directory from terminal
    Run the command "yarn" to install all the node packages needed for the project
    Run "npm start" and navigate to http://localhost:3000 to see the output

  ## Project Structure
    Source (src)
      actions
        |- Action Types (actionTypes)
        |- HTTP Request Actions (httpRequestActions.js)
      components
        |- [Component Name]
          |-- Component Specific Styles
        |- Parent Component (App.js)
        |- Routes Component (AppRoute.js)
      reducers
        |- [Reducer Name]
      services
        |- [API Service]
      store
        |- [Application Store]
      index.html
      index.js
    Config
      |- Webpack configuration
    Packages (package.json)

  ## Features
    React Redux
    D3
    SCSS integration
