import * as types from './actionTypes';
import * as constants from './applicationConstants';
import GitApiService from '../services/GitApiRepoService';
import SessionStorageService from '../services/StorageService';
import {beginXhrCall, errorXhrCall, endXhrCall} from './httpRequestActions';

export function loadGitUserReposListSuccess(userRepoList) {
    return { type: types.LOAD_GIT_REPO_LIST_SUCCESS, userRepoList };
}

export function setGitAuthenticationToken(authenticationToken) {
    return { type: types.LOAD_GIT_USER_AUTHENTICATION_TOKEN, authenticationToken };
}

export function loadGitRepoIssuesSuccess(reposIssuesList) {
    return { type: types.LOAD_GIT_REPO_ISSUES_SUCCESS, reposIssuesList };
}

export function setSelectedRepo(repoName) {
    return { type: types.SET_SELECTED_REPO_NAME, repoName};
}

export function setIssuePriority(fromIssueId, toIssueId) {
    return { type: types.UPDATE_ISSUE_PRIORITY, fromIssueId, toIssueId};
}

export function checkAndUpdateGitToken(authenticationToken) {
    return { type: types.CHECK_AND_UPDATE_GIT_TOKEN, authenticationToken };
}

export function loadGitRepos(accessToken) {
    return function(dispatch) {
        SessionStorageService.setItem(constants.CHEGG_ASSIGNMENT_GIT_TOKEN, accessToken);
        dispatch(beginXhrCall());
        return GitApiService.getData(accessToken).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(endXhrCall());
                    dispatch(loadGitUserReposListSuccess(json));
                });
            }
            else {
                response.json().then(json => {
                    dispatch(endXhrCall());
                    dispatch(errorXhrCall(json.message));
                });
            }
        }).catch(error => {
            dispatch(endXhrCall());
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function loadGitRepoIssues(accessToken, repoName) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return GitApiService.getRepoIssues(accessToken, repoName).then(response => {
            if(response.ok) {
                response.json().then(json => {
                    dispatch(endXhrCall());
                    dispatch(loadGitRepoIssuesSuccess(json));
                });
            }
            else {
                response.json().then(json => {
                    dispatch(endXhrCall());
                    dispatch(errorXhrCall(json.message));
                });
            }
        }).catch(error => {
            dispatch(endXhrCall());
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

export function saveGitAuthenticationToken(authenticationToken) {
    return function(dispatch) {
        dispatch(setGitAuthenticationToken(authenticationToken));
    };
}

export function saveSelectedRepo(repoName) {
    return function(dispatch) {
        dispatch(setSelectedRepo(repoName));
    };
}

export function updateIssuePriority(fromIssueId, toIssueId) {
    return function (dispatch) {
        dispatch(setIssuePriority(fromIssueId, toIssueId));
    };
}

export function checkExistingGitToken() {
    return function(dispatch) {
        if(SessionStorageService.checkItem(constants.CHEGG_ASSIGNMENT_GIT_TOKEN)) {
            dispatch(checkAndUpdateGitToken(SessionStorageService.getItem(constants.CHEGG_ASSIGNMENT_GIT_TOKEN)));
        }
    };
}

