import React from 'react';
import { BrowserRouter, Route, Link } from 'react-router-dom';
import HomePage from './Home/HomePage';


class AppRoutes extends React.Component {
    render() {
        return (
            <BrowserRouter>
                <div className="page-container">
                    <div>
                        <Route exact path="/" component={HomePage}/>
                    </div>
                </div>
            </BrowserRouter>
        );
    }
}

export default AppRoutes;
