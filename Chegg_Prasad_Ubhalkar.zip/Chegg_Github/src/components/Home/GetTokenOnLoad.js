import React, {PropTypes} from 'react';
import ModalDialog from '../Shared/Modal';
import * as gitUsersActions from '../../actions/gitReposActions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

class GetTokenOnLoad extends React.Component {
    constructor(props, context) {
        super(props, context);
        this.gitUserToken = null;
        this.clickProceedGitTokenHandler = this.clickProceedGitTokenHandler.bind(this);
        this.updateGitUserToken = this.updateGitUserToken.bind(this);
    }

    componentDidMount() {
        this.refs.gitAccessTokenModal.open();
    }

    clickProceedGitTokenHandler() {
        if(this.gitUserToken) {
            this.refs.gitAccessTokenModal.close();
            this.props.actions.saveGitAuthenticationToken(this.gitUserToken);
        }
    }

    updateGitUserToken(event) {
        this.gitUserToken =  event.target.value;
    }

    render() {
        const dialogAttrs = {
            size: "sm",
            title:"Please enter Git Authentication Token",
            showDefaultClose: "show",
            showSubmitBtn: "show",
            submitLabel: "Proceed",
            onSubmit: this.clickProceedGitTokenHandler,
            showCancelBtn: "hide"
        };
        return (
            <ModalDialog ref={"gitAccessTokenModal"} attrs={dialogAttrs}>
                <div className={"panel panel-default"}>
                    <input type={"text"}
                           onChange={this.updateGitUserToken}
                           onBlur={this.updateGitUserToken}
                           className={"form-control"}
                           placeholder={"Git Access Token"}/>
                </div>
            </ModalDialog>
        );
    }
}

GetTokenOnLoad.propTypes = {
    actions: PropTypes.object.isRequired,
};

function mapStateToProps(state) {
    return {
        userAccessToken: state.gitRepos.userAccessToken
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(gitUsersActions, dispatch)
    };
}
export default connect(mapStateToProps, mapDispatchToProps) (GetTokenOnLoad);