import React, {PropTypes} from 'react';
import * as gitUsersActions from '../../actions/gitReposActions';
import * as httpStatus from '../../actions/httpRequestActions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import GetTokenOnLoad from './GetTokenOnLoad';

class HomePage extends React.Component {
    constructor(props, context) {
        super(props, context);
        this.loadRepoIssues = this.loadRepoIssues.bind(this);
        this.swapPriorities = this.swapPriorities.bind(this);
        this.renderIssueList = this.renderIssueList.bind(this);
    }

    componentWillMount() {
        this.props.actions.checkExistingGitToken();
    }

    componentWillReceiveProps(updatedProps){
        if(updatedProps.userAccessToken && !updatedProps.gitReposList && !updatedProps.errorMessage && !updatedProps.ajaxCallInProgress) {
            this.props.actions.loadGitRepos(updatedProps.userAccessToken);
        }
    }

    loadRepoIssues(repoFullName) {
        this.props.actions.saveSelectedRepo(repoFullName);
        this.props.actions.loadGitRepoIssues(this.props.userAccessToken, repoFullName);
    }

    swapPriorities(fromIssueId, toIssueId) {
        this.props.actions.updateIssuePriority(fromIssueId, toIssueId);
    }

    sortIssueByPriority(currentIssues){
        let unsortedPriorities = {};
        let sortedIssues = [];
        for(let issue in currentIssues) {
            if(currentIssues.hasOwnProperty(issue)) {
                let currentIssue = currentIssues[issue];
                if(currentIssue["priority"] && currentIssue["id"]) {
                    unsortedPriorities[currentIssue.priority] = currentIssue.id;
                }
            }
        }
        let unsortedKeys = Object.keys(unsortedPriorities);
        unsortedKeys.sort();
        for(let i = 0; i < unsortedKeys.length; i++){
            sortedIssues.push(unsortedPriorities[unsortedKeys[i]]);
        }
        return sortedIssues;
    }

    renderIssueList() {
        let self = this;
        let currentIssueIds = null;
        let currentIssues = null;
        let selectedRepo = this.props.selectedRepo;
        let issuesByRepositories = this.props.issuesByRepositories;
        if(issuesByRepositories && issuesByRepositories[selectedRepo]){
            currentIssues = this.props.issuesByRepositories[selectedRepo];
            currentIssueIds = self.sortIssueByPriority(currentIssues);
        }
        return (
            <ul className="list-group">
                {(currentIssueIds && currentIssueIds.length) ? currentIssueIds.map((issueId, index) => {
                    return(
                        <li className={"list-group-item row"} key={index}>
                            <span className={"col-md-2"}>
                                {(index !== 0) && <span className={"col-md-1"} title={"Move Up in the list"} onClick={
                                    function(){
                                        self.swapPriorities(issueId, currentIssueIds[index - 1]);
                                    }
                                }><img src={"../../assets/img/uparrow.png"} style={{width: 15 + "px", height: 15 + "px"}}/></span>}
                                {(index !== currentIssueIds.length - 1) &&
                                    <span title={"Move Down in the list"}
                                          className={"col-md-1"}
                                          onClick={
                                             function(){
                                                 self.swapPriorities(issueId, currentIssueIds[index + 1]);
                                             }
                                          }>
                                        <img src={"../../assets/img/downarrow.png"} style={{width: 15 + "px", height: 15 + "px"}}/>
                                    </span>}
                            </span>
                            <span className={"col-md-4"}>{currentIssues[issueId].title}</span>
                        </li>
                    );
                }): <li className={"list-group-item"}> No Issues Loaded </li>}
            </ul>
        );
    }

    render() {
        const repoList = this.props.gitReposList;
        const userTokenAvailable = this.props.userAccessToken;
        let self = this;
        let selectedRepo = this.props.selectedRepo;
        return (
            <div className={"col-md-12 homepage"}>
                <div className={"col-md-6"}>
                    {!userTokenAvailable && <GetTokenOnLoad>{" "}</GetTokenOnLoad> }
                    <ul className="list-group">
                        {repoList && repoList.length && repoList.map((repo, index) => {
                            return(
                                <li className={(selectedRepo === repo.full_name) ? "active list-group-item" : "list-group-item"} key={index}
                                    onClick={function(){
                                        self.loadRepoIssues(repo.full_name);
                                    }}>
                                    {repo.name}
                                </li>
                            );
                        })}
                    </ul>
                </div>
                <div className={"col-md-6"}>
                    {self.renderIssueList()}
                </div>
            </div>
        );
    }
}

HomePage.propTypes = {
    actions: PropTypes.object.isRequired,
    gitReposList: PropTypes.array,
    userAccessToken: PropTypes.string,
    selectedRepo: PropTypes.string,
    issuesByRepositories: PropTypes.object,
    errorMessage: PropTypes.string
};

function mapStateToProps(state) {
    return {
        gitReposList: state.gitRepos.userRepoList,
        userAccessToken: state.gitRepos.userAccessToken,
        selectedRepo:  state.gitRepos.selectedRepo,
        issuesByRepositories: state.gitRepos.issuesByRepositories,
        errorMessage: state.httpStatus.errorMessage,
        ajaxCallInProgress: state.httpStatus.ajaxCallInProgress
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(gitUsersActions, dispatch),
        httpStatus: bindActionCreators(httpStatus, dispatch)
    };
}
export default connect(mapStateToProps, mapDispatchToProps) (HomePage);