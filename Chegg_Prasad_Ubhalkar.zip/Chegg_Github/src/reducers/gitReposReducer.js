import * as types from '../actions/actionTypes';
import initialState from './initialState';

export default function gitRepo(state = initialState.github, action) {
    let updatedRepoIssues = null;
    switch (action.type) {
        case types.LOAD_GIT_REPO_LIST_SUCCESS:
            return Object.assign({}, state, {
                userRepoList: action.userRepoList,
                gitTokenValid: true
            });
        case types.LOAD_GIT_USER_AUTHENTICATION_TOKEN:
        case types.CHECK_AND_UPDATE_GIT_TOKEN:
            return Object.assign({}, state, {
                userAccessToken: action.authenticationToken
            });
        case types.SET_SELECTED_REPO_NAME:
            return Object.assign({}, state, {
                selectedRepo: action.repoName
            });
        case types.LOAD_GIT_REPO_ISSUES_SUCCESS:
            updatedRepoIssues = formatIssueList(state.issuesByRepositories, action.reposIssuesList, state.selectedRepo);
            return Object.assign({}, state, {
                issuesByRepositories: updatedRepoIssues
            });
        case types.UPDATE_ISSUE_PRIORITY:
            updatedRepoIssues = swapIssuePriorities(state.issuesByRepositories, state.selectedRepo, action.toIssueId, action.fromIssueId);
            return Object.assign({}, state, {
                issuesByRepositories: updatedRepoIssues
            });
        default:
            return state;
    }
}

function formatIssueList(issuesByRepositories, currentIssueList, selectedRepo) {
    let updatedIssuesByRepositories = JSON.parse(JSON.stringify(issuesByRepositories));
    let listOfIssues = {};

    if(currentIssueList && currentIssueList.length) {
        for(let i = 0; i < currentIssueList.length; i++) {
            if(!currentIssueList[i].hasOwnProperty("priority")) {
                currentIssueList[i]["priority"] = i + 1;
            }
            listOfIssues[currentIssueList[i].id] =  currentIssueList[i];
        }
    }
    if(selectedRepo) {
        updatedIssuesByRepositories[selectedRepo] = listOfIssues;
    }

    return updatedIssuesByRepositories;
}

function swapIssuePriorities(issuesList, selectedRepo, toIssueId, fromIssueId) {
    let currentIssueList = JSON.parse(JSON.stringify(issuesList));
    let tempPriority = currentIssueList[selectedRepo][toIssueId]["priority"];
    currentIssueList[selectedRepo][toIssueId]["priority"] = currentIssueList[selectedRepo][fromIssueId]["priority"];
    currentIssueList[selectedRepo][fromIssueId]["priority"] = tempPriority;
    return currentIssueList;
}