import {combineReducers} from 'redux';
import gitRepos from './gitReposReducer';
import httpStatus from './httpRequestReducer';

const rootReducer = combineReducers({
    gitRepos,
    httpStatus
});

export default rootReducer;